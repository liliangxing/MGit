---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: maks

---

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior:
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

**Expected behavior**
A clear and concise description of what you expected to happen.

**Screenshots**
If applicable, add screenshots to help explain your problem.

**Smartphone (please complete the following information):**
 - Device: [e.g. Pixel 3a]
 - OS: [e.g. Android 9]
 - App Version [e.g. 1.5.3]

**Additional context**
Add any other context about the problem here.
